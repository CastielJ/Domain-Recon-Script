
#This tool is for legal penetration testing and educational purposes only XD.

# A LITE VERSION OF MY SCRIPT. FIRST TIME MAKING THIS. FUTURE IMPROVEMENTS GUARANTEED

- this is a bash-framework for a passive and active target recon
This is a OSINT Domain recon script. First time making a project like this
hope you will like it.

# WHAT INSTRUMENTS WILL WE USE?

subfinder
amass
whois
dig
curl
jq
sslscan
host
whatweb
gobuster
nuclei
httpx
waybackurls
gau
gf
nmap


# DEPENDENCES

Installing:
```bash
   *sudo apt install whois dnsutils curl jq sslscan bind9-host whatweb gobuster nmap
   * `go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest`
   * `go install github.com/OWASP/Amass/v3/...`
   * `go install github.com/projectdiscovery/nuclei/v2/cmd/nuclei@latest`
   * `go install github.com/projectdiscovery/httpx/cmd/httpx@latest`
   * `go install github.com/tomnomnom/waybackurls@latest`
   * `go install github.com/lc/gau/v2/cmd/gau@latest`
   * `go install github.com/1ndianl33t/Gf@latest`



# FIRST TIME MAKING THINGS  LIKE THIS. THANKS FOR LOOKING AT IT OR EVEN USING. MADE WITH LOVE <3


